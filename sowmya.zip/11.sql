select productid, productname, unitsinstock, companyname, contactname
 from customers,products;

